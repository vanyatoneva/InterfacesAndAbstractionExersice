﻿
using BorderControl;
using BorderControl.Models;
using BorderControl.Models.Interfaces;

List<IIdentifiable> tryingToEnter = new();
string[] commArgs = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

while (commArgs[0] != "End")
{
    IIdentifiable identifiable = null;
    if(commArgs.Length == 3)
    {
        identifiable = new Citizen(commArgs[0], int.Parse(commArgs[1]), commArgs[2]);
    }
    else
    {
        identifiable = new Robot(commArgs[0], commArgs[1]); 
    }
    tryingToEnter.Add(identifiable);
    commArgs = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
}

string fakeIds = Console.ReadLine();
//tryingToEnter.RemoveAll(i => i.Id.EndsWith(fakeIds));

//foreach(IIdentifiable identifiable in tryingToEnter)
//{
//    Console.WriteLine(identifiable.Id);
//}

List<IIdentifiable> detained = tryingToEnter.FindAll(i => i.Id.EndsWith(fakeIds));
foreach(IIdentifiable identifiable in detained)
{
    Console.WriteLine(identifiable.Id);
}